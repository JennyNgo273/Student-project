import java.util.Scanner;

public class XuLy {

	public XuLy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("Vui long nhap ten SV: ");
		String ten = scan.nextLine();
		System.out.print("Vui long nhap email:");
		String email = scan.nextLine();

		System.out.print("Vui long nhap diem toan:");
		float toan = Float.parseFloat(scan.nextLine());

		System.out.print("Vui long nhap diem ly:");
		float ly = Float.parseFloat(scan.nextLine());

		System.out.print("Vui long nhap diem hoa:");
		float hoa = Float.parseFloat(scan.nextLine());

		SinhVien sv2 = new SinhVien(ten, email);
		sv2.setDiemToan(toan);
		sv2.setDiemLy(ly);
		sv2.setDiemHoa(hoa);
		sv2.tinhDiemTB();
		

		System.out.println("Ten: " + sv2.getHoTen() + " - Email: " + sv2.getEmail() + "- DTB:" + sv2.getDiemTB());

	}

}
